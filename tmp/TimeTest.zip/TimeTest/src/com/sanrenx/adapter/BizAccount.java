package com.sanrenx.adapter;

public class BizAccount {

}
